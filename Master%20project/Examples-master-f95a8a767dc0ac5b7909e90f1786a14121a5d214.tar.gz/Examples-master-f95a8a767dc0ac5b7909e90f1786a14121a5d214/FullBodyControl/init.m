addpath('../../Libraries/');
addpath('./init_script/');

open_system('nmc_full_body_simmechanics_3fbl.slx');
%open_system('nmc_full_body_simmechanics.mdl');