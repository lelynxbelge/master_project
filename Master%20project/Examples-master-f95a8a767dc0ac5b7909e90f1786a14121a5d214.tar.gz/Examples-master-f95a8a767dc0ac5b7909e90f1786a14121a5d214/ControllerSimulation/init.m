addpath('../../Libraries/');
addpath('./init_script/');

%open_system('nmc_full_body_simmechanics.mdl');


%%

% DATA FORMAT INFORMATION
% Knee: extension is negative
% Hip: extension is positive
% Ankle: extension is positive
load('./data/100_ss_proc.mat')

%% plot test
rr = 3000:3500;

plot(data.leftStance(rr)*0.01,'g')
hold on
plot((data.angHipL(rr)),'r')
plot((data.angKneL(rr)),'b')
plot((data.angAnkL(rr)),'k')

%% preprocess

dataNew.angHipL = data.angHipL/180*pi;
dataNew.angKneL = data.angKneL/180*pi;
dataNew.angAnkL = data.angAnkL/180*pi;

dataNew.angHipR = data.angHipR/180*pi;
dataNew.angKneR = data.angKneR/180*pi;
dataNew.angAnkR = data.angAnkR/180*pi;


%% Angle transformation (see Readme.md of mainRep).
% Here we go from Amy to Geyer, so 

dataNew.angHipL = dataNew.angHipL+pi;
dataNew.angKneL = dataNew.angKneL+pi;
dataNew.angAnkL = dataNew.angAnkL+pi/2;
dataNew.angHipR = dataNew.angHipR+pi;
dataNew.angKneR = dataNew.angKneR+pi;
dataNew.angAnkR = dataNew.angAnkR+pi/2;


%% Add the derivatives 

dataNew.dangHipL = diff(dataNew.angHipL)*data.frameRate;
dataNew.dangKneL = diff(dataNew.angKneL)*data.frameRate;
dataNew.dangAnkL = diff(dataNew.angAnkL)*data.frameRate;
dataNew.dangHipR = diff(dataNew.angHipR)*data.frameRate;
dataNew.dangKneR = diff(dataNew.angKneR)*data.frameRate;
dataNew.dangAnkR = diff(dataNew.angAnkR)*data.frameRate;

dataNew.angHipL = dataNew.angHipL(1:end-1);
dataNew.angKneL = dataNew.angKneL(1:end-1);
dataNew.angAnkL = dataNew.angAnkL(1:end-1);
dataNew.angHipR = dataNew.angHipR(1:end-1);
dataNew.angKneR = dataNew.angKneR(1:end-1);
dataNew.angAnkR = dataNew.angAnkR(1:end-1);

%% Add the stance

dataNew.leftStance = data.leftStance(1:end-1);
dataNew.rightStance = data.rightStance(1:end-1);



%% Increase the sampling time
actualFrameRate=data.frameRate;
desiredFrameRate=1000;


dataNew.time100hz = 0:1/actualFrameRate:1/actualFrameRate*(size(dataNew.angHipL,1)-1);
dataNew.time1khz = 0:1/desiredFrameRate:1/data.frameRate*(size(dataNew.angHipL,1)-1);

dataNew.angHipL = spline(dataNew.time100hz, dataNew.angHipL, dataNew.time1khz);
dataNew.dangHipL = spline(dataNew.time100hz, dataNew.dangHipL, dataNew.time1khz);
dataNew.angKneL = spline(dataNew.time100hz, dataNew.angKneL, dataNew.time1khz);
dataNew.dangKneL = spline(dataNew.time100hz, dataNew.dangKneL, dataNew.time1khz);
dataNew.angAnkL = spline(dataNew.time100hz, dataNew.angAnkL, dataNew.time1khz);
dataNew.dangAnkL = spline(dataNew.time100hz, dataNew.dangAnkL, dataNew.time1khz);
dataNew.angHipR = spline(dataNew.time100hz, dataNew.angHipR, dataNew.time1khz);
dataNew.dangHipR = spline(dataNew.time100hz, dataNew.dangHipR, dataNew.time1khz);
dataNew.angKneR = spline(dataNew.time100hz, dataNew.angKneR, dataNew.time1khz);
dataNew.dangKneR = spline(dataNew.time100hz, dataNew.dangKneR, dataNew.time1khz);
dataNew.angAnkR = spline(dataNew.time100hz, dataNew.angAnkR, dataNew.time1khz);
dataNew.dangAnkR = spline(dataNew.time100hz, dataNew.dangAnkR, dataNew.time1khz);


dataNew.leftStance=spline(dataNew.time100hz,dataNew.leftStance,dataNew.time1khz);
dataNew.rightStance=spline(dataNew.time100hz,dataNew.rightStance,dataNew.time1khz);

dataNew.rightStance(dataNew.rightStance > 0.5) = 1;
dataNew.rightStance(dataNew.rightStance < 0.5) = 0;
dataNew.leftStance(dataNew.leftStance > 0.5) = 1;
dataNew.leftStance(dataNew.leftStance < 0.5) = 0;



%% LOPES TEST
timestamp = dataNew.time1khz;

LeftLeg = struct;
LeftLeg.time = dataNew.time1khz;
LeftLeg.signals.values = [
        dataNew.leftStance; ... 
        dataNew.angHipL; ...
        dataNew.dangHipL; ...
        dataNew.angKneL; ...
        dataNew.dangKneL
        ];

LeftLeg.signals.dimensions = 5;


RightLeg = struct;
RightLeg.time = dataNew.time1khz;
RightLeg.signals.values = [
        dataNew.rightStance; ... 
        dataNew.angHipR; ...
        dataNew.dangHipR; ...
        dataNew.angKneR; ...
        dataNew.dangKneR
        ];
    
RightLeg.signals.dimensions = 5;

time_end = timestamp(end);

Trunk = struct;
Trunk.time = dataNew.time1khz;
Trunk.signals.values = [
        ones(1,length(timestamp));...
        zeros(1,length(timestamp))];

data_lopes_ddt = [timestamp;...
    Trunk.signals.values;...
    LeftLeg.signals.values;...
    RightLeg.signals.values];   
save('data_lopes.mat','data_lopes_ddt');
sim('hip_knee_datadriventest')
figure;
plot(Tau)
hold on; plot(dataNew.time100hz,data.momHipL(1:end-1),'--')
xlim([0 10])
grid on ;

%% Achilles
timestamp = dataNew.time1khz;

LeftLeg = [
        dataNew.leftStance; ... 
        dataNew.angAnkL; ...
        dataNew.dangAnkL
        ];
    
RightLeg = [
        dataNew.leftStance; ... 
        dataNew.angAnkL; ...
        dataNew.dangAnkL
        ];

    time_end = timestamp(end);
    
data_ankle_ddt = [timestamp;LeftLeg;RightLeg];   
save('data_ankle.mat','data_ankle_ddt');
sim('ankle_datadriventest')
    
    
   