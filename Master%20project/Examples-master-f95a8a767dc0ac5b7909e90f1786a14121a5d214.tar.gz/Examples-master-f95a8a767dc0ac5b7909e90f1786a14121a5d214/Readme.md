# Installation 


1. Clone the repositories 
   For the examples to work you will the following two repositories : 
   - Examples repo (this one) : https://gitlab.com/symbitron_simulink_nmc/Examples
   - Libraries repo : https://gitlab.com/symbitron_simulink_nmc/Libraries


2. Go in the libraries folder and rename one of the nmc_2014.slx or nmc_2015.slx (depending on you matlab version) file to nmc.slx
   The library has been tested with Matlab 2014b and Matlab 2015b so please tie to those version if you can. 


#Examples 

1. FullBody examples :
   - Go in the Examples/FullBodyControl/ folder from matlab 
   - Make sur that the subfolder init_script and the Libraries folder are both in you matlab path (you can do so by using the matlab interface or the matlab add_path command line). 
   - Open the folder with the following nmc_full_body_simmechanics_3fbl.slx. 
   - You should be able to run by clicking on the play button 

2. ControllerSimulation examples : 
   This folder contains example of controllers with existing data of other experiments.
   - Add the subfolder init_script to your matlab path 
   - Launch the init.m file this will run a simulation of the achilles controller. 


# Ressources to learn Simulink 
   - I highly recommend you to follow the tutorial on simulink here if you don't know it : http://ch.mathworks.com/support/learn-with-matlab-tutorials.html?refresh=true

